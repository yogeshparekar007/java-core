package com.mphasis.query;

public class FindProductsQuery {

}
